NARUTO STORM ARENA - PROJECT ANDROID

Ini adalah project Android WebView untuk game Naruto Storm Arena.
Game asli berada di app/src/main/assets/.

BUILD DI HP:
1. Buka project ini di aplikasi IDE Android yang mendukung project Gradle.
2. Tunggu Gradle sync selesai.
3. Pilih Build/Assemble Debug atau Build APK.
4. APK debug akan dibuat oleh IDE.

Catatan: project ini membutuhkan Android SDK + Gradle/Android build tools di perangkat pembuat APK.
Saya tidak mengklaim file APK sudah dibuat di sini; yang dibuat adalah project siap-build.

Landscape dan fullscreen sudah diatur di AndroidManifest/MainActivity.
